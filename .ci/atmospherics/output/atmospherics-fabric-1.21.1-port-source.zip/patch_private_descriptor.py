#!/usr/bin/env python3
from __future__ import annotations

import struct
import sys
from pathlib import Path

OLD = "(Lnet/minecraft/core/particles/ParticleType;Ljava/lang/Object;)V"
NEW = "(Lnet/minecraft/core/particles/ParticleType;Lnet/minecraft/client/particle/ParticleEngine$SpriteParticleRegistration;)V"


def u2(data: bytes, offset: int) -> int:
    return struct.unpack_from(">H", data, offset)[0]


def patch(path: Path) -> None:
    data = path.read_bytes()
    if data[:4] != b"\xca\xfe\xba\xbe":
        raise SystemExit(f"Not a class file: {path}")

    cp_count = u2(data, 8)
    offset = 10
    output = bytearray(data[:10])
    index = 1
    replacements = 0

    while index < cp_count:
        tag = data[offset]
        output.append(tag)
        offset += 1

        if tag == 1:  # CONSTANT_Utf8
            length = u2(data, offset)
            offset += 2
            raw = data[offset:offset + length]
            offset += length
            text = raw.decode("utf-8")
            if text == OLD:
                raw = NEW.encode("utf-8")
                replacements += 1
            output.extend(struct.pack(">H", len(raw)))
            output.extend(raw)
        elif tag in (3, 4):
            output.extend(data[offset:offset + 4])
            offset += 4
        elif tag in (5, 6):
            output.extend(data[offset:offset + 8])
            offset += 8
            index += 1
        elif tag in (7, 8, 16, 19, 20):
            output.extend(data[offset:offset + 2])
            offset += 2
        elif tag in (9, 10, 11, 12, 17, 18):
            output.extend(data[offset:offset + 4])
            offset += 4
        elif tag == 15:
            output.extend(data[offset:offset + 3])
            offset += 3
        else:
            raise SystemExit(f"Unsupported constant-pool tag {tag} at index {index}")
        index += 1

    output.extend(data[offset:])
    if replacements != 1:
        raise SystemExit(f"Expected one descriptor replacement in {path}, got {replacements}")
    path.write_bytes(output)
    print(f"Patched private SpriteParticleRegistration ABI in {path}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: patch_private_descriptor.py <class-file>")
    patch(Path(sys.argv[1]))
