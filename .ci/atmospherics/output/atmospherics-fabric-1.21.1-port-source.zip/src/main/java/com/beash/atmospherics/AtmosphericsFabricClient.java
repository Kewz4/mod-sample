package com.beash.atmospherics;

import com.beash.atmospherics.particle.AtmosphericsParticleSheets;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicInteger;

public final class AtmosphericsFabricClient implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("Atmospherics/FabricPort");
    private static final AtomicInteger SMOKE_TEST_TICKS = new AtomicInteger();

    @Override
    public void onInitializeClient() {
        IEventBus compatibilityBus = new IEventBus() {
        };

        new Atmospherics(compatibilityBus);
        new AtmosphericsClient(new ModContainer());

        Atmospherics.onRegisterKeyMappings(new RegisterKeyMappingsEvent());
        AtmosphericsClient.onRegisterParticleProviders(new RegisterParticleProvidersEvent());

        FabricLoader.getInstance().getModContainer(Atmospherics.MOD_ID).ifPresent(container ->
                ResourceManagerHelper.registerBuiltinResourcePack(
                        ResourceLocation.fromNamespaceAndPath(Atmospherics.MOD_ID, "atmospherics_pack"),
                        container,
                        ResourcePackActivationType.DEFAULT_ENABLED));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Atmospherics.onClientTick(new ClientTickEvent.Post());
            if (Boolean.getBoolean("atmospherics.fabric.port.smokeTest")
                    && SMOKE_TEST_TICKS.incrementAndGet() >= 120) {
                LOGGER.info("Atmospherics Fabric smoke test completed after 120 client ticks");
                client.stop();
            }
        });

        HudRenderCallback.EVENT.register((guiGraphics, tickCounter) ->
                Atmospherics.onRenderGui(new RenderGuiEvent.Post(guiGraphics)));

        WorldRenderEvents.AFTER_ENTITIES.register(context ->
                AtmosphericsClient.onRenderLevelStage(new RenderLevelStageEvent(
                        RenderLevelStageEvent.Stage.AFTER_ENTITIES,
                        context.matrixStack())));

        CoreShaderRegistrationCallback.EVENT.register(context ->
                context.register(
                        ResourceLocation.fromNamespaceAndPath(Atmospherics.MOD_ID, "particle_no_cutoff"),
                        DefaultVertexFormat.PARTICLE,
                        shader -> AtmosphericsParticleSheets.noCutoffProgram = shader));

        LOGGER.info("Atmospherics Fabric bridge initialized for Minecraft 1.21.1");
    }
}
