package net.neoforged.neoforge.client.event;

public abstract class ClientTickEvent {
    private ClientTickEvent() {
    }

    public static final class Post extends ClientTickEvent {
        public Post() {
        }
    }
}
