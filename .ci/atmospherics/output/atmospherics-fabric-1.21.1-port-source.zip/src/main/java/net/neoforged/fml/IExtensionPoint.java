package net.neoforged.fml;

public interface IExtensionPoint {
}
