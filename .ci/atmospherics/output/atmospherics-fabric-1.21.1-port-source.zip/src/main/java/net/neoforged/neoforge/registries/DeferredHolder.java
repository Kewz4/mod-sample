package net.neoforged.neoforge.registries;

import java.util.Objects;
import java.util.function.Supplier;

public final class DeferredHolder<R, T extends R> implements Supplier<T> {
    private final String name;
    private final Supplier<? extends T> supplier;
    private volatile T value;

    DeferredHolder(String name, Supplier<? extends T> supplier) {
        this.name = Objects.requireNonNull(name, "name");
        this.supplier = Objects.requireNonNull(supplier, "supplier");
    }

    void bind(T value) {
        this.value = Objects.requireNonNull(value, "value");
    }

    T create() {
        return supplier.get();
    }

    String name() {
        return name;
    }

    @Override
    public T get() {
        T current = value;
        if (current == null) {
            throw new IllegalStateException("Deferred registry entry has not been bound yet: " + name);
        }
        return current;
    }
}
