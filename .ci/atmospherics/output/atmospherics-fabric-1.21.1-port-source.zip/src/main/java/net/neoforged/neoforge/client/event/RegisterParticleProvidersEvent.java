package net.neoforged.neoforge.client.event;

import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class RegisterParticleProvidersEvent {
    /**
     * Compiled with Object because Mojang declares SpriteParticleRegistration as a private nested type.
     * The build patches this method descriptor to the exact NeoForge ABI after javac completes.
     */
    public <T extends ParticleOptions> void registerSpriteSet(ParticleType<T> type, Object registration) {
        ParticleFactoryRegistry.getInstance().register(type, sprites -> invokeFactory(registration, sprites));
    }

    @SuppressWarnings("unchecked")
    private static <T extends ParticleOptions> ParticleProvider<T> invokeFactory(Object registration, SpriteSet sprites) {
        try {
            Method candidate = null;
            for (Method method : registration.getClass().getMethods()) {
                if (method.getName().equals("create") && method.getParameterCount() == 1) {
                    candidate = method;
                    break;
                }
            }
            if (candidate == null) {
                for (Method method : registration.getClass().getDeclaredMethods()) {
                    if (method.getName().equals("create") && method.getParameterCount() == 1) {
                        candidate = method;
                        break;
                    }
                }
            }
            if (candidate == null) {
                throw new NoSuchMethodException("No SpriteParticleRegistration#create method found");
            }
            candidate.setAccessible(true);
            return (ParticleProvider<T>) candidate.invoke(registration, sprites);
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException exception) {
            throw new IllegalStateException("Unable to adapt Atmospherics particle factory to Fabric", exception);
        }
    }
}
