package net.neoforged.neoforge.event;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;

public final class AddPackFindersEvent {
    private final PackType packType;

    public AddPackFindersEvent(PackType packType) {
        this.packType = packType;
    }

    public PackType getPackType() {
        return packType;
    }

    public void addPackFinders(
            ResourceLocation location,
            PackType type,
            Component title,
            PackSource source,
            boolean enabled,
            Pack.Position position) {
        // Fabric registration is handled directly by the bridge entrypoint.
    }
}
