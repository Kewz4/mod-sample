package net.neoforged.fml;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ModContainer {
    private final Map<Class<?>, IExtensionPoint> extensionPoints = new ConcurrentHashMap<>();

    public <T extends IExtensionPoint> void registerExtensionPoint(Class<T> pointClass, T point) {
        extensionPoints.put(pointClass, point);
    }

    @SuppressWarnings("unchecked")
    public <T extends IExtensionPoint> T getExtensionPoint(Class<T> pointClass) {
        return (T) extensionPoints.get(pointClass);
    }
}
