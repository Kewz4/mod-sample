package net.neoforged.bus.api;

/** Minimal compatibility marker used by the original NeoForge binary. */
public interface IEventBus {
}
