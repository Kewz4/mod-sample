package net.neoforged.neoforge.client.event;

import net.minecraft.client.gui.GuiGraphics;
import java.util.Objects;

public abstract class RenderGuiEvent {
    private final GuiGraphics guiGraphics;

    private RenderGuiEvent(GuiGraphics guiGraphics) {
        this.guiGraphics = Objects.requireNonNull(guiGraphics, "guiGraphics");
    }

    public GuiGraphics getGuiGraphics() {
        return guiGraphics;
    }

    public static final class Post extends RenderGuiEvent {
        public Post(GuiGraphics guiGraphics) {
            super(guiGraphics);
        }
    }
}
