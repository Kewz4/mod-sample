package net.neoforged.neoforge.client.event;

import com.mojang.blaze3d.vertex.PoseStack;

public final class RenderLevelStageEvent {
    private final Stage stage;
    private final PoseStack poseStack;

    public RenderLevelStageEvent(Stage stage, PoseStack poseStack) {
        this.stage = stage;
        this.poseStack = poseStack;
    }

    public Stage getStage() {
        return stage;
    }

    public PoseStack getPoseStack() {
        return poseStack;
    }

    public enum Stage {
        AFTER_ENTITIES
    }
}
