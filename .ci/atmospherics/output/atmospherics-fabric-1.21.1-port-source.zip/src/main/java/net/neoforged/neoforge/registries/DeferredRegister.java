package net.neoforged.neoforge.registries;

import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;

public final class DeferredRegister<R> {
    private final Registry<R> registry;
    private final String namespace;
    private final List<DeferredHolder<R, ? extends R>> entries = new ArrayList<>();
    private boolean registered;

    private DeferredRegister(Registry<R> registry, String namespace) {
        this.registry = Objects.requireNonNull(registry, "registry");
        this.namespace = Objects.requireNonNull(namespace, "namespace");
    }

    public static <R> DeferredRegister<R> create(Registry<R> registry, String namespace) {
        return new DeferredRegister<>(registry, namespace);
    }

    public synchronized <T extends R> DeferredHolder<R, T> register(String name, Supplier<? extends T> supplier) {
        if (registered) {
            throw new IllegalStateException("Cannot add registry entries after registration");
        }
        DeferredHolder<R, T> holder = new DeferredHolder<>(name, supplier);
        entries.add(holder);
        return holder;
    }

    public synchronized void register(IEventBus ignored) {
        if (registered) {
            return;
        }
        for (DeferredHolder<R, ? extends R> untyped : entries) {
            bind(untyped);
        }
        registered = true;
    }

    private <T extends R> void bind(DeferredHolder<R, T> holder) {
        T value = holder.create();
        Registry.register(registry, ResourceLocation.fromNamespaceAndPath(namespace, holder.name()), value);
        holder.bind(value);
    }
}
