#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
JAR = ROOT / "build" / "libs" / "atmospherics-2.6.5-fabric-1.21.1.jar"
REPORT = ROOT / "build" / "atmospherics-2.6.5-fabric-1.21.1-validation.txt"


def fail(message: str) -> None:
    raise SystemExit(f"VALIDATION FAILED: {message}")


if not JAR.is_file():
    fail(f"missing remapped JAR: {JAR}")

sha256 = hashlib.sha256(JAR.read_bytes()).hexdigest()
size = JAR.stat().st_size

with zipfile.ZipFile(JAR) as zf:
    bad = zf.testzip()
    if bad:
        fail(f"corrupt ZIP member: {bad}")

    names = zf.namelist()
    duplicates = [name for name, count in Counter(names).items() if count > 1]
    if duplicates:
        fail(f"duplicate ZIP members: {duplicates[:10]}")

    required = {
        "fabric.mod.json",
        "atmospherics.mixins.json",
        "com/beash/atmospherics/Atmospherics.class",
        "com/beash/atmospherics/AtmosphericsClient.class",
        "com/beash/atmospherics/AtmosphericsFabricClient.class",
        "net/neoforged/neoforge/registries/DeferredRegister.class",
        "assets/atmospherics/shaders/core/particle_no_cutoff.json",
        "resourcepacks/atmospherics_pack/pack.mcmeta",
    }
    missing = sorted(required.difference(names))
    if missing:
        fail(f"missing required members: {missing}")

    forbidden = {
        "META-INF/neoforge.mods.toml",
        "META-INF/mods.toml",
    }
    present_forbidden = sorted(forbidden.intersection(names))
    if present_forbidden:
        fail(f"NeoForge loader metadata remained: {present_forbidden}")

    metadata = json.loads(zf.read("fabric.mod.json"))
    if metadata.get("id") != "atmospherics":
        fail("fabric.mod.json has the wrong mod id")
    if metadata.get("version") != "2.6.5-fabric.1":
        fail(f"unexpected mod version: {metadata.get('version')!r}")
    if metadata.get("environment") != "client":
        fail("port is not marked client-only")
    entrypoints = metadata.get("entrypoints", {}).get("client", [])
    if "com.beash.atmospherics.AtmosphericsFabricClient" not in entrypoints:
        fail("Fabric client entrypoint is missing")
    depends = metadata.get("depends", {})
    if depends.get("minecraft") != "1.21.1":
        fail("Minecraft dependency is not pinned to 1.21.1")
    if depends.get("fabricloader") != ">=0.19.3":
        fail("Fabric Loader dependency is not >=0.19.3")

    mixins = json.loads(zf.read("atmospherics.mixins.json"))
    client_mixins = mixins.get("client", [])
    if len(client_mixins) != len(set(client_mixins)):
        fail("duplicate client mixins remain")
    if mixins.get("compatibilityLevel") != "JAVA_21":
        fail("mixin compatibility level is not JAVA_21")

    class_count = sum(name.endswith(".class") for name in names)
    if class_count < 230:
        fail(f"unexpectedly low class count: {class_count}")

lines = [
    "Atmospherics 2.6.5 Fabric 1.21.1 port validation",
    "=================================================",
    "",
    "Result: PASS",
    f"File: {JAR.name}",
    f"Size: {size} bytes",
    f"SHA-256: {sha256}",
    "Minecraft: 1.21.1",
    "Fabric Loader: 0.19.3 or newer",
    "Fabric API used for build: 0.116.7+1.21.1",
    "Java: 21",
    f"Class files: {class_count}",
    "",
    "Checks passed:",
    "- Valid ZIP/JAR with no duplicate members",
    "- Fabric metadata and client entrypoint present",
    "- Original Atmospherics classes and resources included",
    "- Compatibility bridge/shim classes included",
    "- NeoForge loader metadata removed",
    "- Duplicate mixin declaration removed",
    "- Mixin compatibility raised to Java 21",
    "- Production namespace remap task completed",
]
REPORT.parent.mkdir(parents=True, exist_ok=True)
REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(REPORT)
print(f"SHA-256 {sha256}")
